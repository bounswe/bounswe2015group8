var searchData=
[
  ['add',['add',['../class_mathematical_operations.html#ab27168f2e3b036da157cd26da71329a5',1,'MathematicalOperations']]]
];
