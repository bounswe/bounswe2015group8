var searchData=
[
  ['power',['power',['../class_mathematical_operations.html#a95c136ea3cf89a0d1c169417c0e20031',1,'MathematicalOperations']]],
  ['powertest',['powerTest',['../class_test_mathematical_operations.html#a193ccee08cc043e629c7715701a6b31d',1,'TestMathematicalOperations']]]
];
