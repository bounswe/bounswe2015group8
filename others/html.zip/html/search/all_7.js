var searchData=
[
  ['square',['square',['../class_mathematical_operations.html#a796a2a7bb6233290eb0bbfed56f8aeb5',1,'MathematicalOperations']]],
  ['squaretest',['squareTest',['../class_test_mathematical_operations.html#a5126789fea4f8c8ed2156891ce1c7847',1,'TestMathematicalOperations']]],
  ['subtract',['subtract',['../class_mathematical_operations.html#a622129148f4640e202b027fb4e14dc83',1,'MathematicalOperations']]],
  ['subtracttest',['subtractTest',['../class_test_mathematical_operations.html#aa4d14db53b79abab6b9f438916c4b45c',1,'TestMathematicalOperations']]]
];
